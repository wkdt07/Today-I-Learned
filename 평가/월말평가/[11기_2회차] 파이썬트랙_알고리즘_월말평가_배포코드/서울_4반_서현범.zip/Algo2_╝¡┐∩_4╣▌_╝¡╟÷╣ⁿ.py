'''
게임 단계에 따라 3x3에서 8x8 규격의 표적이 나타납니다.
- 가로 한 줄에서 한 개의 표적을 선택할 수 있습니다.
- 세로 한 줄에서 한 개의 표적을 선택할 수 있습니다.-> 가로, 세로 둘 다 기억해야함
- 한 줄에서 2개 이상의 표적을 맞추면 그 단계는 실격입니다. -> 실격하면 안 된다.
- 어떤 단계에는 표적 한 개의 점수가 음수로 나타날 수 있습니다. 이
표적을 맞히면 그 단계는 실격입니다. -> 음수 맞추면 안 된다
'''

T = int(input())

for t in range(1,T+1):
    N = int(input())
    arr = [list(map(int,input().split())) for _ in range(N)]

    vst_j= [True]*(N)

    # sum_v = 0
    sum_lst = []




    # while True:
    #     for i in range(N):
    #         if vst_i[i]:
    #             vst_i[i] = False
    #             for j in range(N):
    #                 if vst_j[j]:
    #                     vst_j[j] = False
    #                     sum_v += arr[i][j]
    #     sum_lst.append(sum_v)


    def rating(i=0,sum_v = 0,vst_j = [True]*(N)):
        global sum_lst
        # global sum_v
        # vst_i[i] = False
        if i == N:
            sum_lst.append(sum_v)
            return
        for j in range(N):
            if vst_j[j] and arr[i][j]>=1:
                sum_v += arr[i][j]

                vst_j[j] = False
                rating(i+1,sum_v,vst_j)
                vst_j[j] = True
                # return

    rating()
    rst = max(sum_lst)
    print(f'#{t} {rst}')

            # else:
            #     # vst_i[i] = True
            #     # vst_j[j] = True
            #     return
    #     # for i in range(N):
    #     #     if vst_i[i]:
    #     #         vst_i[i] = False
    #     #         for j in range(N):
    #     #             if vst_j[j] and arr[i][j]>0:
    #     #                 sum_v += arr[i][j]
    #     #                 vst_j[j] = False
    #     #                 rating(sum_v,cnt + 1)
    #     #                 vst_i[i] = True
    #     #                 vst_j[j] = True
    #     #                 return
    #     # return

